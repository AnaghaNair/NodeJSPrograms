var {defineSupportCode} = require('cucumber');
var reporter = require('cucumber-html-reporter');

defineSupportCode(function ({registerHandler}) {


    registerHandler('AfterFeatures', function () {

        var options = {
            theme: 'bootstrap',
            jsonFile: './reports/cucumber-json-report.json',
            output: './reports/cucumber-html-report.html',
            reportSuiteAsScenarios: true,
            launchReport: true,
        };

        reporter.generate(options);

        return;
    });
});