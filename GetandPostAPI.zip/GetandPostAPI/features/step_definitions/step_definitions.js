const { Given, When, Then } = require('cucumber');
const got = require('got');
const assert = require('assert');
var request = require('request');
var ActualResCode;
var ActualUserID;

var jsonFormat = {
    headers: { 'Content-Type': 'application/json' },
    json: true
};

Given(/^I make a call  to the api "([^"]*)"$/, async function (url) {
    result = await got.get(url, jsonFormat);
    ActualResCode = result.statusCode
    ActualUserID = result.body.id
});

Then(/^I validate the status code in response as "([^"]*)"$/, async function (ResponseStatus) {

    console.log('statusCode:', ActualResCode);
    assert.equal(ResponseStatus, ActualResCode);
});

Then(/^I Validate the userId as "([^"]*)"$/, async function (UserID) {
    console.log('ID:', ActualUserID);
    assert.equal(UserID, ActualUserID);
});

Given(/^I make a Post call to the  api "([^"]*)" and I validate the status as "([^"]*)" and userid as "([^"]*)"$/, async function (url,Status,id) {

    var xml2js = require("xml2js");
    const fs = require('fs');
    let testData = fs.readFileSync('features/Resources/Request.json');
    let RequestData = JSON.parse(testData);

    request.post(
        url,
        { json: RequestData},
        function (error, response, body) {
            assert.equal(202, response.statusCode)
            assert.equal(1, response.body.userId)
        }
    );

});
